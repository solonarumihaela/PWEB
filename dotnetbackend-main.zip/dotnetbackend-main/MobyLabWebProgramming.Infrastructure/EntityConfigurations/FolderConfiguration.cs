using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MobyLabWebProgramming.Core.Entities;

namespace MobyLabWebProgramming.Infrastructure.EntityConfigurations;

public class FolderConfiguration : IEntityTypeConfiguration<Folder>
{
    public void Configure(EntityTypeBuilder<Folder> builder)
    {
        builder.Property(d => d.Id).IsRequired();
        builder.HasKey(d => d.Id);
        builder.Property(d => d.BacalaureatPdfPath).HasMaxLength(255).IsRequired(false);
        builder.Property(d => d.IdentityCardPdfPath).HasMaxLength(255).IsRequired(false);
        builder.Property(d => d.PassportPdfPath).HasMaxLength(255).IsRequired(false);
        builder.Property(d => d.PhotosPdfPath).HasMaxLength(255).IsRequired(false);
        
        // UserId Foreign key and One2One relation (Folder2User)
        builder.HasOne(d => d.User)
            .WithOne(s => s.Folder)
            .HasForeignKey<Folder>(d => d.UserId)
            .IsRequired()
            .OnDelete(DeleteBehavior.Cascade);
    }
}
