using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MobyLabWebProgramming.Core.Entities;

namespace MobyLabWebProgramming.Infrastructure.EntityConfigurations;

public class SpecialtyConfiguration : IEntityTypeConfiguration<Specialty>
{
    public void Configure(EntityTypeBuilder<Specialty> builder)
    {
        builder.Property(sp => sp.Id).IsRequired();
        builder.HasKey(sp => sp.Id);
        builder.Property(sp => sp.Name).HasMaxLength(255).IsRequired();
        builder.Property(sp => sp.Description).HasMaxLength(1024);
        builder.Property(sp => sp.CreatedAt).IsRequired();
        builder.Property(sp => sp.UpdatedAt).IsRequired();

        // FacultyId Foreign key and Many2One relation (Specialties2Faculty)
        builder.HasOne(sp => sp.Faculty)
            .WithMany(f => f.Specialties)
            .HasForeignKey(sp => sp.FacultyId)
            .IsRequired()
            .OnDelete(DeleteBehavior.Restrict);
    }
}
