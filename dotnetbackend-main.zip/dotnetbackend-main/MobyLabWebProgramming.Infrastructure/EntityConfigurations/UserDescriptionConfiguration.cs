using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MobyLabWebProgramming.Core.Entities;

namespace MobyLabWebProgramming.Infrastructure.EntityConfigurations;

public class UserDescriptionConfiguration : IEntityTypeConfiguration<UserDescription>
{
    public void Configure(EntityTypeBuilder<UserDescription> builder)
    {

        builder.HasKey(ud => ud.Id);
        builder.Property(d => d.FirstName).IsRequired().HasMaxLength(100);
        builder.Property(d => d.LastName).IsRequired().HasMaxLength(100);
        builder.Property(d => d.Gender).HasMaxLength(10);
        builder.Property(d => d.Nationality).HasMaxLength(50);
        builder.Property(d => d.PassportNumber).IsRequired().HasMaxLength(20);
        builder.Property(d => d.IdentificationNumber).IsRequired().HasMaxLength(20);
        
        // UserId Foreign key and One2One relation (UserDescription2User)
        builder.HasOne(d => d.User)
            .WithOne(s => s.UserDescription)
            .HasForeignKey<UserDescription>(d => d.UserId)
            .IsRequired()
            .OnDelete(DeleteBehavior.Cascade);
    }
}