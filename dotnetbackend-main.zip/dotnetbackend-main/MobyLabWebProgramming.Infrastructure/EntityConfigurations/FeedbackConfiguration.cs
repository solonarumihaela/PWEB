using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MobyLabWebProgramming.Core.Entities;

namespace MobyLabWebProgramming.Infrastructure.EntityConfigurations;

public class FeedbackConfiguration : IEntityTypeConfiguration<Feedback>
{
    public void Configure(EntityTypeBuilder<Feedback> builder)
    {
        builder.Property(f => f.Id).IsRequired();
        builder.HasKey(f => f.Id);
        builder.Property(f => f.Date).IsRequired();
        builder.Property(f => f.Message).HasMaxLength(1024).IsRequired();
        
        // UserId Foreign key and Many2One relation (Feedbacks2User)
        builder.HasOne(f => f.User)
            .WithMany(s => s.Feedbacks)
            .HasForeignKey(f => f.UserId)
            .IsRequired()
            .OnDelete(DeleteBehavior.Cascade);

        // SpecialtyId Foreign key and Many2One relation (Feedbacks2Specialty)
        builder.HasOne(f => f.Specialty)
            .WithMany()
            .HasForeignKey(f => f.SpecialtyId)
            .IsRequired()
            .OnDelete(DeleteBehavior.Restrict);
    }
}
