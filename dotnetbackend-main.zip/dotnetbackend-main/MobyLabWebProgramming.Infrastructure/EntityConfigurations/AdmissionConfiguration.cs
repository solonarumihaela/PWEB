using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MobyLabWebProgramming.Core.Entities;

namespace MobyLabWebProgramming.Infrastructure.EntityConfigurations;

public class AdmissionApplicationConfiguration : IEntityTypeConfiguration<Admission>
{
    public void Configure(EntityTypeBuilder<Admission> builder)
    {
        builder.Property(a => a.Id).IsRequired();
        builder.HasKey(a => a.Id);
        builder.Property(a => a.ApplicationDate).IsRequired();
        builder.Property(a => a.ResultDate);
        builder.Property(a => a.Status).IsRequired();
        // A student can try to admit to a specialty once
        builder.HasIndex(a => new { a.UserId, a.SpecialtyId }).IsUnique();
        builder.Property(a => a.CreatedAt).IsRequired();
        builder.Property(a => a.UpdatedAt).IsRequired();

        // UserId Foreign key and Many2One relation (Addmisions2User)
        builder.HasOne(a => a.User)
            .WithMany(s => s.Admissions)
            .HasForeignKey(a => a.UserId)
            .IsRequired()
            .OnDelete(DeleteBehavior.Cascade);
        
        // SpecialtyId Foreign key and Many2One relation (Addmisions2SpecialtyId)
        builder.HasOne(a => a.Specialty)
            .WithMany(s => s.Admissions)
            .HasForeignKey(a => a.SpecialtyId)
            .IsRequired()
            .OnDelete(DeleteBehavior.Restrict);
    }
}
