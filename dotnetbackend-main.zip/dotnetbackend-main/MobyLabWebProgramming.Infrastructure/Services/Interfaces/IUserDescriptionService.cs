using MobyLabWebProgramming.Core.DataTransferObjects;
using MobyLabWebProgramming.Core.Requests;
using MobyLabWebProgramming.Core.Responses;

namespace MobyLabWebProgramming.Infrastructure.Services.Interfaces;

public interface IUserDescriptionService
{
    public Task<ServiceResponse<UserDescriptionDTO>> GetUserDescription(Guid id, CancellationToken cancellationToken = default);
    public Task<ServiceResponse<PagedResponse<UserDescriptionDTO>>> GetUsersDescriptions(PaginationSearchQueryParams pagination, CancellationToken cancellationToken = default);
    public Task<ServiceResponse<int>> GetUserDescriptionCount(CancellationToken cancellationToken = default);
    public Task<ServiceResponse> AddUserDescription(UserDescriptionAddDTO userdesc, UserDTO? requestingUser = default, CancellationToken cancellationToken = default);
    public Task<ServiceResponse> UpdateUserDescription(UserDescriptionUpdateDTO userdesc, UserDTO? requestingUser = default, CancellationToken cancellationToken = default);
    public Task<ServiceResponse> DeleteUserDescription(Guid id, UserDTO? requestingUser = default, CancellationToken cancellationToken = default);
}
