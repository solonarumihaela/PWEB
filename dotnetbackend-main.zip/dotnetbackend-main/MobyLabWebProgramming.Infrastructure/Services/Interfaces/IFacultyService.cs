using MobyLabWebProgramming.Core.DataTransferObjects;
using MobyLabWebProgramming.Core.Requests;
using MobyLabWebProgramming.Core.Responses;

namespace MobyLabWebProgramming.Infrastructure.Services.Interfaces;

public interface IFacultyService
{
    public Task<ServiceResponse<FacultyDTO>> GetFaculty(Guid id, CancellationToken cancellationToken = default);
    public Task<ServiceResponse<PagedResponse<FacultyDTO>>> GetFaculties(PaginationSearchQueryParams pagination, CancellationToken cancellationToken = default);
    public Task<ServiceResponse<int>> GetFacultyCount(CancellationToken cancellationToken = default);
    public Task<ServiceResponse> AddFaculty(FacultyAddDTO faculty, UserDTO? requestingUser = default, CancellationToken cancellationToken = default);
    public Task<ServiceResponse> UpdateFaculty(FacultyDTO faculty, UserDTO? requestingUser = default, CancellationToken cancellationToken = default);
    public Task<ServiceResponse> DeleteFaculty(Guid id, UserDTO? requestingUser = default, CancellationToken cancellationToken = default);
}