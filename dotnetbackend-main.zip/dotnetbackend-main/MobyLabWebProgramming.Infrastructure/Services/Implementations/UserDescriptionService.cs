using System.Net;
using MobyLabWebProgramming.Core.Constants;
using MobyLabWebProgramming.Core.DataTransferObjects;
using MobyLabWebProgramming.Core.Entities;
using MobyLabWebProgramming.Core.Enums;
using MobyLabWebProgramming.Core.Errors;
using MobyLabWebProgramming.Core.Requests;
using MobyLabWebProgramming.Core.Responses;
using MobyLabWebProgramming.Core.Specifications;
using MobyLabWebProgramming.Infrastructure.Database;
using MobyLabWebProgramming.Infrastructure.Repositories.Interfaces;
using MobyLabWebProgramming.Infrastructure.Services.Interfaces;

namespace MobyLabWebProgramming.Infrastructure.Services.Implementations;

public class UserDescriptionService : IUserDescriptionService
{
    private readonly IRepository<WebAppDatabaseContext> _repository;

    public UserDescriptionService(IRepository<WebAppDatabaseContext> repository)
    {
        _repository = repository;
    }

    public async Task<ServiceResponse<UserDescriptionDTO>> GetUserDescription(Guid id, CancellationToken cancellationToken = default)
    {
        var result = await _repository.GetAsync(new UserDescriptionProjectionSpec(id), cancellationToken);

        return result != null ? 
            ServiceResponse<UserDescriptionDTO>.ForSuccess(result) : 
            ServiceResponse<UserDescriptionDTO>.FromError(CommonErrors.UserDescriptionNotFound);
    }

    public async Task<ServiceResponse<PagedResponse<UserDescriptionDTO>>> GetUsersDescriptions(PaginationSearchQueryParams pagination, CancellationToken cancellationToken = default)
    {
        var result = await _repository.PageAsync(pagination, new UserDescriptionProjectionSpec(pagination.Search), cancellationToken);

        return ServiceResponse<PagedResponse<UserDescriptionDTO>>.ForSuccess(result);
    }

    public async Task<ServiceResponse<int>> GetUserDescriptionCount(CancellationToken cancellationToken = default) => 
        ServiceResponse<int>.ForSuccess(await _repository.GetCountAsync<UserDescription>(cancellationToken));

    public async Task<ServiceResponse> AddUserDescription(UserDescriptionAddDTO userdesc, UserDTO? requestingUser, CancellationToken cancellationToken = default)
    {
        if (requestingUser != null && requestingUser.Role != UserRoleEnum.Admin && requestingUser.Id != userdesc.UserId)
        {
            return ServiceResponse.FromError(new(HttpStatusCode.Forbidden, "Only the admin or the own user can add the user description!", ErrorCodes.CannotAdd));
        }

        var result = await _repository.GetAsync(new UserDescriptionSpec(userdesc.IdentificationNumber), cancellationToken);

        if (result != null)
        {
            return ServiceResponse.FromError(new(HttpStatusCode.Conflict, "The user description already exists!", ErrorCodes.UserAlreadyExists));
        }

        await _repository.AddAsync(new UserDescription
        {
            UserId = userdesc.UserId,
            FirstName = userdesc.FirstName,
            LastName = userdesc.LastName,
            Gender = userdesc.Gender,
            Nationality = userdesc.Nationality,
            PassportNumber = userdesc.PassportNumber, 
            IdentificationNumber = userdesc.IdentificationNumber 
        }, cancellationToken); 

        return ServiceResponse.ForSuccess();
    }

    public async Task<ServiceResponse> UpdateUserDescription(UserDescriptionUpdateDTO userdesc, UserDTO? requestingUser, CancellationToken cancellationToken = default)
    {
        if (requestingUser != null && requestingUser.Role != UserRoleEnum.Admin && requestingUser.Id != userdesc.UserId)
        {
            return ServiceResponse.FromError(new(HttpStatusCode.Forbidden, "Only the admin or the own user can update the user description!", ErrorCodes.CannotUpdate));
        }

        var entity = await _repository.GetAsync(new UserDescriptionSpec(userdesc.Id), cancellationToken); 

        if (entity != null)
        {
            entity.FirstName = userdesc.FirstName ?? entity.FirstName;
            entity.LastName = userdesc.LastName ?? entity.LastName;

            await _repository.UpdateAsync(entity, cancellationToken);
        }

        return ServiceResponse.ForSuccess();
    }

    public async Task<ServiceResponse> DeleteUserDescription(Guid id, UserDTO? requestingUser = default, CancellationToken cancellationToken = default)
    {
        if (requestingUser != null && requestingUser.Role != UserRoleEnum.Admin)
        {
            return ServiceResponse.FromError(new(HttpStatusCode.Forbidden, "Only the admin can delete the user description!", ErrorCodes.CannotDelete));
        }

        await _repository.DeleteAsync<UserDescription>(id, cancellationToken);

        return ServiceResponse.ForSuccess();
    }
}
