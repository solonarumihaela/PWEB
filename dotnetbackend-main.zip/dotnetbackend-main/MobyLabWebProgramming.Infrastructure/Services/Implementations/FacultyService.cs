using System.Net;
using MobyLabWebProgramming.Core.Constants;
using MobyLabWebProgramming.Core.DataTransferObjects;
using MobyLabWebProgramming.Core.Entities;
using MobyLabWebProgramming.Core.Enums;
using MobyLabWebProgramming.Core.Errors;
using MobyLabWebProgramming.Core.Requests;
using MobyLabWebProgramming.Core.Responses;
using MobyLabWebProgramming.Core.Specifications;
using MobyLabWebProgramming.Infrastructure.Database;
using MobyLabWebProgramming.Infrastructure.Repositories.Interfaces;
using MobyLabWebProgramming.Infrastructure.Services.Interfaces;

namespace MobyLabWebProgramming.Infrastructure.Services.Implementations;

public class FacultyService : IFacultyService
{
    private readonly IRepository<WebAppDatabaseContext> _repository;

    public FacultyService(IRepository<WebAppDatabaseContext> repository)
    {
        _repository = repository;
    }

    public async Task<ServiceResponse<FacultyDTO>> GetFaculty(Guid id, CancellationToken cancellationToken = default)
    {
        var result = await _repository.GetAsync(new FacultyProjectionSpec(id), cancellationToken);

        return result != null ? 
            ServiceResponse<FacultyDTO>.ForSuccess(result) : 
            ServiceResponse<FacultyDTO>.FromError(CommonErrors.FacultyNotFound);
    }

    public async Task<ServiceResponse<PagedResponse<FacultyDTO>>> GetFaculties(PaginationSearchQueryParams pagination, CancellationToken cancellationToken = default)
    {
        var result = await _repository.PageAsync(pagination, new FacultyProjectionSpec(pagination.Search), cancellationToken);

        return ServiceResponse<PagedResponse<FacultyDTO>>.ForSuccess(result);
    }

    public async Task<ServiceResponse<int>> GetFacultyCount(CancellationToken cancellationToken = default) => 
        ServiceResponse<int>.ForSuccess(await _repository.GetCountAsync<Faculty>(cancellationToken));

    public async Task<ServiceResponse> AddFaculty(FacultyAddDTO faculty, UserDTO? requestingUser, CancellationToken cancellationToken = default)
    {
        if (requestingUser != null && requestingUser.Role != UserRoleEnum.Admin)
        {
            return ServiceResponse.FromError(new(HttpStatusCode.Forbidden, "Only the admin can add the faculty description!", ErrorCodes.CannotAdd));
        }

        var result = await _repository.GetAsync(new FacultySpec(faculty.Name), cancellationToken);

        if (result != null)
        {
            return ServiceResponse.FromError(new(HttpStatusCode.Conflict, "The faculty already exists!", ErrorCodes.UserAlreadyExists));
        }

        await _repository.AddAsync(new Faculty
        {
            Name = faculty.Name,
            Description = faculty.Description
        }, cancellationToken); 

        return ServiceResponse.ForSuccess();
    }

    public async Task<ServiceResponse> UpdateFaculty(FacultyDTO faculty, UserDTO? requestingUser, CancellationToken cancellationToken = default)
    {
        if (requestingUser != null && requestingUser.Role != UserRoleEnum.Admin)
        {
            return ServiceResponse.FromError(new(HttpStatusCode.Forbidden, "Only the admin or the own user can update the faculty description!", ErrorCodes.CannotUpdate));
        }

        var entity = await _repository.GetAsync(new FacultySpec(faculty.Id), cancellationToken); 

        if (entity != null)
        {
            entity.Name = faculty.Name ?? entity.Name;
            entity.Description = faculty.Description ?? entity.Description;

            await _repository.UpdateAsync(entity, cancellationToken);
        }

        return ServiceResponse.ForSuccess();
    }

    public async Task<ServiceResponse> DeleteFaculty(Guid id, UserDTO? requestingUser = default, CancellationToken cancellationToken = default)
    {
        if (requestingUser != null && requestingUser.Role != UserRoleEnum.Admin)
        {
            return ServiceResponse.FromError(new(HttpStatusCode.Forbidden, "Only the admin can delete the faculty!", ErrorCodes.CannotDelete));
        }

        await _repository.DeleteAsync<Faculty>(id, cancellationToken);

        return ServiceResponse.ForSuccess();
    }
}
