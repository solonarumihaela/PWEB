using System.Linq.Expressions;
using Ardalis.Specification;
using Microsoft.EntityFrameworkCore;
using MobyLabWebProgramming.Core.DataTransferObjects;
using MobyLabWebProgramming.Core.Entities;

namespace MobyLabWebProgramming.Core.Specifications;

public sealed class UserDescriptionProjectionSpec : BaseSpec<UserDescriptionProjectionSpec, UserDescription, UserDescriptionDTO>
{

    protected override Expression<Func<UserDescription, UserDescriptionDTO>> Spec => e => new()
    {
        Id = e.Id,
        FirstName = e.FirstName,   
        LastName = e.LastName, 
        Gender = e.Gender, 
        Nationality = e.Nationality, 
        PassportNumber = e.PassportNumber,
        IdentificationNumber = e.IdentificationNumber, 
    };

    public UserDescriptionProjectionSpec(bool orderByCreatedAt = true) : base(orderByCreatedAt)
    {
    }

    public UserDescriptionProjectionSpec(Guid id) : base(id)
    {
    }

    public UserDescriptionProjectionSpec(string? search)
    {
        search = !string.IsNullOrWhiteSpace(search) ? search.Trim() : null;

        if (search == null)
        {
            return;
        }

        var searchExpr = $"%{search.Replace(" ", "%")}%";

        Query.Where(e => EF.Functions.ILike(e.FirstName, searchExpr));
    }
}