using MobyLabWebProgramming.Core.Entities;
using Ardalis.Specification;

namespace MobyLabWebProgramming.Core.Specifications;

public class UserDescriptionSpec : BaseSpec<UserDescriptionSpec, UserDescription>
{
    public UserDescriptionSpec(Guid id) : base(id)
    {
    }

    public UserDescriptionSpec(string IdentificationNumber)
    {
        Query.Where(e => e.IdentificationNumber == IdentificationNumber);
    }
}
