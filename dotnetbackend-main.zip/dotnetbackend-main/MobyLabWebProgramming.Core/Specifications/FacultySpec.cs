using MobyLabWebProgramming.Core.Entities;
using Ardalis.Specification;

namespace MobyLabWebProgramming.Core.Specifications;

public class FacultySpec : BaseSpec<FacultySpec, Faculty>
{
    public FacultySpec(Guid id) : base(id)
    {
    }

    public FacultySpec(string Name)
    {
        Query.Where(e => e.Name == Name);
    }
}