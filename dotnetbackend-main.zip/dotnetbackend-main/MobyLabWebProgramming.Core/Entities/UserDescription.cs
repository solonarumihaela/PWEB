namespace MobyLabWebProgramming.Core.Entities;

public class UserDescription : BaseEntity
{
    public Guid UserId { get; set; } // Foreign Key referencing the Student entity
    public string FirstName { get; set; } = default!;
    public string LastName { get; set; } = default!;
    public string Gender { get; set; } = default!;
    public string Nationality { get; set; } = default!;
    public string PassportNumber { get; set; } = default!;
    public string IdentificationNumber { get; set; } = default!;
    
    // Navigation property
    public User User { get; set; } = default!;
}
