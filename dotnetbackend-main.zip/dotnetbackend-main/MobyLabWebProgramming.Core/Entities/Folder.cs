namespace MobyLabWebProgramming.Core.Entities;

public class Folder : BaseEntity
{
    public Guid UserId { get; set; } // Foreign Key to the User entity
    public string BacalaureatPdfPath { get; set; } = default!;
    public string IdentityCardPdfPath { get; set; } = default!;
    public string PassportPdfPath { get; set; } = default!;
    public string PhotosPdfPath { get; set; } = default!;

    // Navigation property
    public User User { get; set; } = default!;
}
