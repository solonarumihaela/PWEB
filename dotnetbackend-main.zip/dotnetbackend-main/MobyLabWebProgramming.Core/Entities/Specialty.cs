namespace MobyLabWebProgramming.Core.Entities;

public class Specialty : BaseEntity
{
    public Guid FacultyId { get; set; } // Foreign Key to the Faculty entity
    public string Name { get; set; } = default!;
    public string Description { get; set; } = default!;

    // Navigation property for One2One relationship with Faculty
    public Faculty Faculty { get; set; } = default!;
    
    // Navigation property for Many2One relationship with AdmissionApplication
    public IEnumerable<Admission>? Admissions { get; set; }
}
