namespace MobyLabWebProgramming.Core.Entities;

public class Feedback : BaseEntity
{
    public Guid UserId { get; set; } // Foreign Key referencing the Student entity
    public Guid SpecialtyId { get; set; } // Foreign Key referencing the Specialty entity
    public DateTime Date { get; set; } = DateTime.UtcNow;
    public string Message { get; set; } = default!;

    // Navigation properties
    public User User { get; set; } = default!;
    public Specialty Specialty { get; set; } = default!;
}
