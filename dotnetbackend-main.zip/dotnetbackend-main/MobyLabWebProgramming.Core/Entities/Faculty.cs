namespace MobyLabWebProgramming.Core.Entities;

public class Faculty : BaseEntity
{
    public string Name { get; set; } = default!;
    public string Description { get; set; } = default!;
    
    // Navigation property for One2Many relationship with Specialty
    public ICollection<Specialty> Specialties { get; set; } = new List<Specialty>();
}
