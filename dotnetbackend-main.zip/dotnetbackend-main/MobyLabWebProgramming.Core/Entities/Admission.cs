using MobyLabWebProgramming.Core.Enums;

namespace MobyLabWebProgramming.Core.Entities;

public class Admission : BaseEntity
{
    public Guid UserId { get; set; } = default!; // Foreign Key referencing the Student entity
    public Guid SpecialtyId { get; set; } = default!; // Foreign Key referencing the Specialty entity
    public DateTime ApplicationDate { get; set; } = default!;
    public DateTime? ResultDate { get; set; } = default!;
    public AdmisionStatus Status { get; set; } = default!;

    // Navigation properties
    public User User { get; set; } = default!;
    public Specialty Specialty { get; set; } = default!;
}
