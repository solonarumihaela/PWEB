using Ardalis.SmartEnum;
using Ardalis.SmartEnum.SystemTextJson;
using System.Text.Json.Serialization;

namespace MobyLabWebProgramming.Core.Enums;

[JsonConverter(typeof(SmartEnumNameConverter<AdmisionStatus, string>))]
public sealed class AdmisionStatus : SmartEnum<AdmisionStatus, string>
{
    public static readonly AdmisionStatus Pending = new(nameof(Pending), "Pending");
    public static readonly AdmisionStatus Admitted = new(nameof(Admitted), "Admitted");
    public static readonly AdmisionStatus Rejected = new(nameof(Rejected), "Rejected");
    
    private AdmisionStatus(string name, string value) : base(name, value)
    {
    }
}