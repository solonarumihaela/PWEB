namespace MobyLabWebProgramming.Core.DataTransferObjects;

public class UserDescriptionDTO
{
    public Guid Id { get; set; }
    public string FirstName { get; set; } = default!;
    public string LastName { get; set; } = default!;
    public string Gender { get; set; } = default!;
    public string Nationality { get; set; } = default!;
    public string PassportNumber { get; set; } = default!;
    public string IdentificationNumber { get; set; } = default!;
}