namespace MobyLabWebProgramming.Core.DataTransferObjects;

public record UserDescriptionUpdateDTO(Guid Id, Guid UserId, string? FirstName = default, string? LastName = default);