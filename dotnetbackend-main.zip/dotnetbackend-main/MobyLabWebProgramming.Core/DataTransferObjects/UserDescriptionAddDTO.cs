namespace MobyLabWebProgramming.Core.DataTransferObjects;

public class UserDescriptionAddDTO
{
    public Guid UserId { get; set; }
    public string FirstName { get; set; } = default!;
    public string LastName { get; set; } = default!;
    public string Gender { get; set; } = default!;
    public string Nationality { get; set; } = default!;
    public string PassportNumber { get; set; } = default!;
    public string IdentificationNumber { get; set; } = default!;
}