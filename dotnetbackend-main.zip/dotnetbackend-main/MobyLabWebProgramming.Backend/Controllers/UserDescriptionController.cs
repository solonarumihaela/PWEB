using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MobyLabWebProgramming.Core.DataTransferObjects;
using MobyLabWebProgramming.Core.Entities;
using MobyLabWebProgramming.Core.Requests;
using MobyLabWebProgramming.Core.Responses;
using MobyLabWebProgramming.Infrastructure.Authorization;
using MobyLabWebProgramming.Infrastructure.Extensions;
using MobyLabWebProgramming.Infrastructure.Services.Interfaces;

namespace MobyLabWebProgramming.Backend.Controllers;

[ApiController]
[Route("api/[controller]/[action]")]
public class UserDescriptionController : AuthorizedController
{
    private readonly IUserDescriptionService _userDescriptionService;
    
    public UserDescriptionController(IUserDescriptionService userdescService, IUserService userService) : base(userService)
    {
        _userDescriptionService = userdescService ?? throw new ArgumentNullException(nameof(userdescService));
    }
    
    [Authorize] 
    [HttpGet("{id:guid}")] 
    public async Task<ActionResult<RequestResponse<UserDescriptionDTO>>> GetById([FromRoute] Guid id) 
    {
        var currentUser = await GetCurrentUser();

        return currentUser.Result != null ? 
            this.FromServiceResponse(await _userDescriptionService.GetUserDescription(id)) : 
            this.ErrorMessageResult<UserDescriptionDTO>(currentUser.Error);
    }
    
    
    [Authorize]
    [HttpPost] 
    public async Task<ActionResult<RequestResponse>> Add([FromBody] UserDescriptionAddDTO userdesc)
    {
        var currentUser = await GetCurrentUser();

        return currentUser.Result != null ?
            this.FromServiceResponse(await _userDescriptionService.AddUserDescription(userdesc, currentUser.Result)) :
            this.ErrorMessageResult(currentUser.Error);
    }
    
    [Authorize]
    [HttpPut] 
    public async Task<ActionResult<RequestResponse>> Update([FromBody] UserDescriptionUpdateDTO userdesc) 
    {
        var currentUser = await GetCurrentUser();

        return currentUser.Result != null ?
            this.FromServiceResponse(await _userDescriptionService.UpdateUserDescription(userdesc with
            {
                LastName = !string.IsNullOrWhiteSpace(userdesc.LastName) ? userdesc.LastName : null,
                FirstName = !string.IsNullOrWhiteSpace(userdesc.FirstName) ? userdesc.FirstName : null

            }, currentUser.Result)) :
            this.ErrorMessageResult(currentUser.Error);
    }
    
    [Authorize]
    [HttpDelete("{id:guid}")] 
    public async Task<ActionResult<RequestResponse>> Delete([FromRoute] Guid id)
    {
        var currentUser = await GetCurrentUser();

        return currentUser.Result != null ?
            this.FromServiceResponse(await _userDescriptionService.DeleteUserDescription(id)) :
            this.ErrorMessageResult(currentUser.Error);
    }
}
